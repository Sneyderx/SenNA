
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConNectionMySQL {
    private String nombre_BaseDatos = "heladeria_database";
    private String user = "root";
    private String contraseña = "admin";
    private String url = "jdbc:mysql://localhost:3306/" + nombre_BaseDatos;
    Connection conn = null;
    
    public Connection getConnection(){
        try{
            //Obtener valor del Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Obtener la Conexion
            conn = DriverManager.getConnection(url, user, contraseña);
        }catch(ClassNotFoundException e){
            System.err.println("Ha ocurrido un ClassNotFoundException" + e.getMessage());
        }catch(SQLException e){
            System.err.println("Ha ocurrido un SQLException" + e.getMessage());
        }
        return conn;
    }

}
