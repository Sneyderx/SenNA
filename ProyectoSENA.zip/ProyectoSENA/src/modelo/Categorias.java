package modelo;

public class Categorias {
    private int id;
    private String nombre;
    private String created;
    private String updated;

    public Categorias() {
    }

    public Categorias(int id, String nombre, String created, String updated) {
        this.id = id;
        this.nombre = nombre;
        this.created = created;
        this.updated = updated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
    
    
}
