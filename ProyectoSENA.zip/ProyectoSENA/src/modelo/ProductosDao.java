package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ProductosDao {

    //Instanciar la Conexion
    ConNectionMySQL cn = new ConNectionMySQL();
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    //Registrar Producto
    public boolean registrarProductoQuery(Productos producto) {
        // Define la consulta SQL para insertar un nuevo producto en la tabla 'productos'
        String query = "INSERT INTO productos (codigo, nombre, descripcion, precio_Unitario, cantidad_Producto, created, updated, categoria_id)"
                + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setInt(1, producto.getCodigo());
            pst.setString(2, producto.getNombre());
            pst.setString(3, producto.getDescripcion());
            pst.setDouble(4, producto.getPrecio_Unitario());
            pst.setInt(5, producto.getCantidad_Producto());
            pst.setTimestamp(6, datetime);
            pst.setTimestamp(7, datetime);
            pst.setInt(8, producto.getCategoria_id());
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;

        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al Registrar el Producto");
            // Retorna falso para indicar que la operación falló
            return false;
        }

    }

    //Listar Productos
    public List listaProductosQuery(String value) {
        // Crea una nueva lista para almacenar objetos de tipo Productos
        List<Productos> lista_productos = new ArrayList();

        // Consulta SQL para obtener todos los productos con sus respectivas categorías
        String query = "SELECT pro.*, ca.nombre AS nombre_categoria FROM productos pro, categorias ca WHERE pro.categoria_id = ca.id";
        // Consulta SQL para buscar productos por nombre
        String query_buscar_producto = "SELECT pro.*, ca.nombre AS nombre_categoria FROM productos pro INNER JOIN categorias ca ON pro.categoria_id = ca.id WHERE pro.nombre LIKE '%" + value + "%'";

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Verifica si se proporcionó un valor para la búsqueda
            if (value.equalsIgnoreCase("")) {
                // Si no se proporcionó un valor, ejecuta la consulta para obtener todas las categorias
                pst = conn.prepareStatement(query);
                rs = pst.executeQuery();
            } else {
                // Si se proporcionó un valor, ejecuta la consulta para buscar la categoria por nombre
                pst = conn.prepareStatement(query_buscar_producto);
                rs = pst.executeQuery();
            }

            // Itera a través de los resultados obtenidos de la consulta
            while (rs.next()) {
                // Crea un nuevo objeto Producto para almacenar los datos del registro actual
                Productos producto = new Productos();
                // Establece los valores de las propiedades del objeto Producto con los datos del registro actual
                producto.setId(rs.getInt("id"));
                producto.setCodigo(rs.getInt("codigo"));
                producto.setNombre(rs.getString("nombre"));
                producto.setDescripcion(rs.getString("descripcion"));
                producto.setPrecio_Unitario(rs.getDouble("precio_Unitario"));
                producto.setCantidad_Producto(rs.getInt("cantidad_Producto"));
                producto.setNombre_categoria(rs.getString("nombre_categoria"));

                // Agrega el objeto Producto a la lista
                lista_productos.add(producto);

            }
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.toString());
        }

        // Retorna la lista de productos obtenida
        return lista_productos;
    }

    //Modificar Producto
    public boolean modificarProductoQuery(Productos producto) {
        // Define la consulta SQL para insertar un nuevo producto en la tabla 'productos'
        String query = "UPDATE productos SET codigo = ?, nombre= ?, descripcion = ?, precio_Unitario = ?, cantidad_Producto = ?, updated= ?, "
                + "categoria_id = ? WHERE id = ?";

        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setInt(1, producto.getCodigo());
            pst.setString(2, producto.getNombre());
            pst.setString(3, producto.getDescripcion());
            pst.setDouble(4, producto.getPrecio_Unitario());
            pst.setInt(5, producto.getCantidad_Producto());
            pst.setTimestamp(6, datetime);
            pst.setInt(7, producto.getCategoria_id());
            pst.setInt(8, producto.getId());
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;

        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al Modificar los datos del Producto");
            // Retorna falso para indicar que la operación falló
            return false;
        }

    }

    //Eliminar Producto
    public boolean eliminarProductoQuery(int id) {
        // Define la consulta SQL para eliminar un producto de la tabla 'productos' basado en su ID
        String query = "DELETE FROM productos WHERE id = " + id;
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Ejecuta la sentencia SQL para eliminar el registro del producto
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "No puede eliminar un producto que tenga relación con otra tabla");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }

    //Buscar Producto
    public Productos buscarProductoQuery(int id) {
        // Consulta SQL para obtener un producto específico con su categoría asociada
        String query = "SELECT pro.*, ca.nombre AS nombre_categoria FROM productos pro "
                + "INNER JOIN categorias ca ON pro.categoria_id = ca.id WHERE pro.id = ?";

        // Crea un nuevo objeto Producto para almacenar los datos del producto encontrado
        Productos producto = new Productos();

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece el valor del parámetro en la sentencia preparada
            // El parámetro es el ID del producto que se desea buscar
            pst.setInt(1, id);
            // Ejecuta la sentencia SQL
            rs = pst.executeQuery();

            // Verifica si se encontró un producto con el ID especificado
            if (rs.next()) {
                // Establece los valores de las propiedades del objeto Producto con los datos del producto encontrado
                producto.setId(rs.getInt("id"));
                producto.setCodigo(rs.getInt("codigo"));
                producto.setNombre(rs.getString("nombre"));
                producto.setDescripcion(rs.getString("descripcion"));
                producto.setPrecio_Unitario(rs.getDouble("precio_Unitario"));
                producto.setCantidad_Producto(rs.getInt("cantidad_Producto"));
                producto.setCategoria_id(rs.getInt("categoria_id"));
                producto.setNombre_categoria(rs.getString("nombre_categoria"));
            }
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        // Retorna el objeto Producto encontrado (o un objeto vacío si no se encontró ningún producto con el ID especificado)
        return producto;
    }

    //Buscar Producto por codigo
    public Productos buscarCodigoQuery(int codigo) {
        // Consulta SQL para obtener un producto específico con su id y nombre asociado
        String query = "SELECT pro.id, pro.nombre FROM productos pro WHERE pro.codigo = ?";

        // Crea un nuevo objeto Producto para almacenar los datos del producto encontrado
        Productos producto = new Productos();

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece el valor del parámetro en la sentencia preparada
            // El parámetro es el codigo del producto que se desea buscar
            pst.setInt(1, codigo);
            // Ejecuta la sentencia SQL
            rs = pst.executeQuery();

            // Verifica si se encontró un producto con el codigo especificado
            if (rs.next()) {
                // Establece los valores de las propiedades del objeto Producto con los datos del producto encontrado
                producto.setId(rs.getInt("id"));
                producto.setNombre(rs.getString("nombre"));

            }
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        // Retorna el objeto Producto encontrado (o un objeto vacío si no se encontró ningún producto con el codigo especificado)
        return producto;
    }

    //Tarer la cantidad de productos
    public Productos buscarIdQuery(int id) {
        // Consulta SQL para obtener la cantidad de un producto basado en su ID
        String query = "SELECT pro.cantidad_Producto FROM productos pro WHERE pro.id = ?";

        // Crea un nuevo objeto Producto para almacenar los datos del producto encontrado
        Productos producto = new Productos();
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);

            // Establece el valor del parámetro en la sentencia preparada
            // El parámetro es el ID del producto que se desea buscar
            pst.setInt(1, id);
            // Ejecuta la sentencia SQL
            rs = pst.executeQuery();

            // Verifica si se encontró un producto con el ID especificado
            if (rs.next()) {
                // Establece la cantidad del producto con el valor obtenido del resultado de la consulta
                producto.setCantidad_Producto(rs.getInt("cantidad_Producto"));
            }
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        // Retorna el objeto Producto con la cantidad del producto encontrado (o un objeto con la cantidad en 0 si no se encontró ningún producto con el ID especificado)
        return producto;
    }

    //Actualizar Stock
    public boolean actualizarStock(int cantidad, int producto_id) {
        // Verificar si la cantidad disponible es suficiente para la venta
        int cantidadDisponible = getCantidadDisponible(producto_id);
        if (cantidadDisponible < cantidad) {
            JOptionPane.showMessageDialog(null, "No hay suficiente stock disponible para esta venta.");
            return false;
        }

        // Consulta SQL para restar la cantidad de un producto vendido basado en su ID
        String query = "UPDATE productos SET cantidad_Producto = ? WHERE id = ?";
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setInt(1, cantidadDisponible - cantidad);
            pst.setInt(2, producto_id);
            // Ejecuta la sentencia SQL para restar la cantidad vendida del stock del producto
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, "Error al actualizar el stock: " + e.getMessage());
        }
        // Retorna falso para indicar que la operación falló
        return false;
    }

    private int getCantidadDisponible(int producto_id) {
        int cantidad = 0;
        String query = "SELECT cantidad_Producto FROM productos WHERE id = ?";

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            pst.setInt(1, producto_id);
            // Ejecuta la consulta SQL
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                cantidad = rs.getInt("cantidad_Producto");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener la cantidad disponible: " + e.getMessage());
        }

        return cantidad;
    }

//    public boolean actualizarStock(int cantidad, int producto_id){
//        // Consulta SQL para actualizar la cantidad de un producto basado en su ID
//        String query = "UPDATE productos SET cantidad_Producto = cantidad_Producto - ? WHERE id = ?";
//        try{
//            // Establece la conexión con la base de datos
//            conn = cn.getConnection();
//            // Prepara la sentencia SQL con la consulta definida
//            pst = conn.prepareStatement(query);
//            // Establece los valores de los parámetros en la sentencia preparada
//            pst.setInt(1, cantidad);
//            pst.setInt(2, producto_id);
//            // Ejecuta la sentencia SQL para actualizar el stock del producto
//            pst.execute();
//            // Retorna verdadero para indicar que la operación fue exitosa
//            return true;
//        }catch(SQLException e){
//            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
//            JOptionPane.showMessageDialog(null, e.getMessage());
//        }
//        // Retorna falso para indicar que la operación falló
//        return false;   
//    }
}
