
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class AdministradoraDao {
    
    
    
    //Instanciar la Conexion
    ConNectionMySQL cn = new ConNectionMySQL();
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    
    //Variables para enviar datos entre interfaces
    public static int id_user = 0;
    public static String nombre_user = "";
    public static String usuario_user = "";
    public static String direccion_user = "";
    public static String email_user = "";
    public static String telefono_user = "";
    public static String rol_user = "";
    
    
    public void obtenerRolUser() {
        
        String query = "SELECT * FROM administradora WHERE id = ?";
        
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            pst.setInt(1, id_user);
            rs = pst.executeQuery();

            if (rs.next()) {
                rol_user = rs.getString("rol");
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener el rol del usuario: " + e.getMessage());
        }
    }

    
    //Metodo del Login
    public Administradora loginQuery(String user, String contraseña){
        String query = "SELECT * FROM administradora WHERE usuario = ? AND contraseña = ?";
        
        Administradora administradora = new Administradora();
        
        try{
            conn = cn.getConnection();
            pst = conn.prepareStatement(query);
            
            //Enviar Parametros
            pst.setString(1, user);
            pst.setString(2, contraseña);
            rs = pst.executeQuery();
            
            //Para saber si los datos de usuario y contraseña coinciden
            if(rs.next()){
                administradora.setId(rs.getInt("id"));
                id_user = administradora.getId();
                administradora.setNombre(rs.getString("nombre"));
                nombre_user = administradora.getNombre();
                administradora.setUsuario(rs.getString("usuario"));
                usuario_user = administradora.getUsuario();
                administradora.setDireccion(rs.getString("direccion"));
                direccion_user = administradora.getDireccion();
                administradora.setTelefono(rs.getString("telefono"));
                telefono_user = administradora.getTelefono();
                administradora.setEmail(rs.getString("email"));
                email_user = administradora.getEmail();
                administradora.setRol(rs.getString("rol"));
                rol_user = administradora.getRol();
                
                
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error al obtener la administracion " + e);
        }
        return administradora;
    }
    
    //Registrar administradora
    public boolean registrarAdministradoraQuery(Administradora administradora){
        String query = "INSERT INTO administradora(id, nombre, usuario, direccion, telefono, email, contraseña, rol, created, updated) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());
        
        try{
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            pst.setInt(1, administradora.getId());
            pst.setString(2, administradora.getNombre());
            pst.setString(3, administradora.getUsuario());
            pst.setString(4, administradora.getDireccion());
            pst.setString(5, administradora.getTelefono());
            pst.setString(6, administradora.getEmail());
            pst.setString(7, administradora.getContraseña());
            pst.setString(8, administradora.getRol());
            pst.setTimestamp(9, datetime);
            pst.setTimestamp(10, datetime);
            
            pst.execute();
            
            return true;
        
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error al registrar la administradora " + e);
            return false;
        }
    }

    //Listar Administradora
    public List listaAdministradoraQuery(String value){
        List<Administradora> lista_administradora = new ArrayList();
        String query = "SELECT * FROM administradora ORDER BY rol ASC";
        String buscar_administradora_query = "SELECT * FROM administradora WHERE id LIKE '%" + value + "%'";
        
        try{
            conn = cn.getConnection();
            
            if(value.equalsIgnoreCase("")){
                pst = conn.prepareStatement(query);
                rs = pst.executeQuery();
            } else{
                pst = conn.prepareStatement(buscar_administradora_query);
                rs = pst.executeQuery();
            }
            
            while(rs.next()){
                Administradora administradora = new Administradora();
                
                administradora.setId(rs.getInt("id"));
                administradora.setNombre(rs.getString("nombre"));
                administradora.setUsuario(rs.getString("usuario"));
                administradora.setDireccion(rs.getString("direccion"));
                administradora.setTelefono(rs.getString("telefono"));
                administradora.setEmail(rs.getString("email"));
                administradora.setRol(rs.getString("rol"));
                
                lista_administradora.add(administradora);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
        return lista_administradora;
    }
    
    //Modificar Administradora
    public boolean modificarAdministradoraQuery(Administradora administradora){
        String query = "UPDATE administradora SET nombre = ?, usuario = ?, direccion= ?, telefono = ?, email = ?, rol = ?, updated = ? WHERE id = ?";
        
        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());
        
        try{
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            pst.setString(1, administradora.getNombre());
            pst.setString(2, administradora.getUsuario());
            pst.setString(3, administradora.getDireccion());
            pst.setString(4, administradora.getTelefono());
            pst.setString(5, administradora.getEmail());
            pst.setString(6, administradora.getRol());
            pst.setTimestamp(7, datetime);
            pst.setInt(8, administradora.getId());
            
            pst.execute();
            
            return true;
        
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error al modificar los datos de la administradora " + e);
            return false;
        }
    }
    
    //Eliminar Usuario
    public boolean eliminarUsuarioQuery(int id){
        String query = "DELETE FROM administradora WHERE id = " + id;
        
        try{
            conn = cn.getConnection();
            pst = conn.prepareStatement(query);
            pst.execute();
            return true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "No puede eliminar el Usuario que tenga relacion con otra tabla" + e.getMessage());
            return false;
        }
    }

    //Cambiar COntraseña
    public boolean cambiarContraseña(Administradora administradora){
        String query = "UPDATE administradora SET contraseña = ? WHERE usuario = '" + usuario_user + "'";
        
        try{
            conn = cn.getConnection();
            pst = conn.prepareStatement(query);
            pst.setString(1, administradora.getContraseña());
            pst.executeUpdate();
            return true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la contraseña " + e);
            return false;
        }
    }  
}
