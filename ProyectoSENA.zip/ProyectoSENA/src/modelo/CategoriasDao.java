package modelo;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class CategoriasDao {

    //Instanciar la Conexion
    ConNectionMySQL cn = new ConNectionMySQL();
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    //Registrar Categorias
    public boolean registrarCategoriasQuery(Categorias categoria) {
        // Define la consulta SQL para insertar una nueva categoria en la tabla 'categorias'
        String query = "INSERT INTO categorias (nombre, created, updated) VALUES(?, ?, ?)";
        
        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setString(1, categoria.getNombre());
            pst.setTimestamp(2, datetime);
            pst.setTimestamp(3, datetime);
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
            
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al registrar la categoria");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }
    
    //Listar categorias
    public List listaCategoriasQuery(String value){
        // Crea una nueva lista para almacenar objetos de tipo Categorias
        List<Categorias> lista_categorias = new ArrayList();
        // Consulta SQL para seleccionar todos los registros de la tabla 'categorias'
        String query = "SELECT * FROM categorias";
        // Consulta SQL para buscar una categoria por nombre (filtrado por el valor proporcionado)
        String query_buscar_categoria = "SELECT * FROM categorias WHERE nombre LIKE '%" + value + "%'";
        try{
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Verifica si se proporcionó un valor para la búsqueda
            if (value.equalsIgnoreCase("")) {
                // Si no se proporcionó un valor, ejecuta la consulta para obtener todas las categorias
                pst = conn.prepareStatement(query);
                rs = pst.executeQuery();
            } else {
                // Si se proporcionó un valor, ejecuta la consulta para buscar la categoria por nombre
                pst = conn.prepareStatement(query_buscar_categoria);
                rs = pst.executeQuery();
            }
            
            // Itera a través de los resultados obtenidos de la consulta
            while(rs.next()){
                // Crea un nuevo objeto Categorias para almacenar los datos del registro actual
                Categorias categoria = new Categorias();
                // Establece los valores de las propiedades del objeto Categorias con los datos del registro actual
                categoria.setId(rs.getInt("id"));
                categoria.setNombre(rs.getString("nombre"));
                
                // Agrega el objeto Categoria a la lista
                lista_categorias.add(categoria);
            }
        }catch(SQLException e){
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.toString());
        }
        // Retorna la lista de categorias obtenida
        return lista_categorias;
    }
    
    //Modificar Categoria
    public boolean modificarCategoriasQuery(Categorias categoria){
        // Define la consulta SQL para actualizar los datos de una categoria en la tabla 'categorias'
        String query = "UPDATE categorias SET nombre = ?, updated = ? WHERE id = ? ";
        
        // Obtiene la fecha y hora actual como un Timestamp para actualizar el campo 'updated'
        Timestamp datetime = new Timestamp(new Date().getTime());
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setString(1, categoria.getNombre());
            pst.setTimestamp(2, datetime);
            pst.setInt(3, categoria.getId());
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
            
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al modificar los datos de la categoria");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }
    
    //Eliminar Categoria
    public boolean eliminarCategoriasQuery(int id) {
        // Define la consulta SQL para eliminar una categoria de la tabla 'categoria' basado en su ID
        String query = "DELETE FROM categorias WHERE id = " + id;
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Ejecuta la sentencia SQL para eliminar el registro del categoria
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "No puede eliminar una categoria que tenga relación con otra tabla");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }
}
