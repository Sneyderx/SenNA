package modelo;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ClientesDao {

    //Instanciar la Conexion
    ConNectionMySQL cn = new ConNectionMySQL();
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    //Registrar Cliente
    public boolean registrarClienteQuery(Clientes cliente) {
        // Define la consulta SQL para insertar un nuevo cliente en la tabla 'clientes'
        String query = "INSERT INTO clientes (id, nombre, direccion, telefono, email, created, updated)"
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setInt(1, cliente.getId());
            pst.setString(2, cliente.getNombre());
            pst.setString(3, cliente.getDireccion());
            pst.setString(4, cliente.getTelefono());
            pst.setString(5, cliente.getEmail());
            pst.setTimestamp(6, datetime);
            pst.setTimestamp(7, datetime);
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al registrar al cliente");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }

    //Listar Clientes
    public List listaClienteQuery(String value) {
        // Crea una nueva lista para almacenar objetos de tipo Clientes
        List<Clientes> lista_cliente = new ArrayList();
        // Consulta SQL para seleccionar todos los registros de la tabla 'clientes'
        String query = "SELECT * FROM clientes";
        // Consulta SQL para buscar un cliente por ID (filtrado por el valor proporcionado)
        String query_buscar_cliente = "SELECT * FROM clientes WHERE id LIKE '%" + value + "%'";
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Verifica si se proporcionó un valor para la búsqueda
            if (value.equalsIgnoreCase("")) {
                // Si no se proporcionó un valor, ejecuta la consulta para obtener todos los clientes
                pst = conn.prepareStatement(query);
                rs = pst.executeQuery();
            } else {
                // Si se proporcionó un valor, ejecuta la consulta para buscar el cliente por ID
                pst = conn.prepareStatement(query_buscar_cliente);
                rs = pst.executeQuery();
            }

            // Itera a través de los resultados obtenidos de la consulta
            while (rs.next()) {
                // Crea un nuevo objeto Cliente para almacenar los datos del registro actual
                Clientes cliente = new Clientes();
                // Establece los valores de las propiedades del objeto Cliente con los datos del registro actual
                cliente.setId(rs.getInt("id"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setDireccion(rs.getString("direccion"));
                cliente.setTelefono(rs.getString("telefono"));
                cliente.setEmail(rs.getString("email"));

                // Agrega el objeto Cliente a la lista
                lista_cliente.add(cliente);
            }
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.toString());
        }
        // Retorna la lista de clientes obtenida
        return lista_cliente;
    }

    //Modificar Cliente
    public boolean modificarClienteQuery(Clientes cliente) {
        // Define la consulta SQL para actualizar los datos de un cliente en la tabla 'clientes'
        String query = "UPDATE clientes SET nombre = ?, direccion = ?, telefono = ?, email = ?, updated = ? "
                + "WHERE id = ?";

        // Obtiene la fecha y hora actual como un Timestamp para actualizar el campo 'updated'
        Timestamp datetime = new Timestamp(new Date().getTime());
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setString(1, cliente.getNombre());
            pst.setString(2, cliente.getDireccion());
            pst.setString(3, cliente.getTelefono());
            pst.setString(4, cliente.getEmail());
            pst.setTimestamp(5, datetime);
            pst.setInt(6, cliente.getId());
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al modificar los datos del cliente");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }

    //Eliminar Cliente
    public boolean eliminarClienteQuery(int id) {
        // Define la consulta SQL para eliminar un cliente de la tabla 'clientes' basado en su ID
        String query = "DELETE FROM clientes WHERE id = " + id;
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Ejecuta la sentencia SQL para eliminar el registro del cliente
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "No puede eliminar un cliente que tenga relación con otra tabla");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }
}