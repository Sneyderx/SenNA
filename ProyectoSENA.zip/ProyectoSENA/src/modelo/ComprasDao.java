package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import static modelo.AdministradoraDao.nombre_user;
import static modelo.AdministradoraDao.rol_user;

public class ComprasDao {

    //Instanciar la Conexion
    ConNectionMySQL cn = new ConNectionMySQL();
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    //Registrar Compra
    public boolean registrarCompraQuery(int empleado_id, double total) {
        // Definición de la consulta SQL para insertar una nueva compra en la tabla 'compras'
        String query = "INSERT INTO compras (total, created) VALUES (?, ?)";

        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            // Establece los valores de los parametros en la consulta SQL
            pst.setDouble(1, total);
            pst.setTimestamp(2, datetime);

            // Ejecuta la consulta SQL para insertar la nueva compra
            pst.execute();

            // Retorna 'true' si la inserción fue exitosa
            return true;

        } catch (SQLException e) {
            // Muestra un mensaje de error en caso de fallo al insertar la compra
            JOptionPane.showMessageDialog(null, "Error al Insertar la compra");

            // Retorna 'false' indicando que la inserción falló
            return false;
        }
    }

    //Rgistrar Detalles de la Compra
    public boolean registrarDetallesCompraQuery(int compra_id, double precio_compra, int cantidad_compra, double subtotal_compra, int producto_id) {

        // Definición de la consulta SQL para insertar los detalles de una compra en la tabla 'detalles_compras'
        String query = "INSERT INTO detalles_compras (compra_id, precio_compra, cantidad_compra, subtotal_compra,"
                + "producto_id) VALUES (?, ?, ?, ?, ?)";

        // Obtiene la fecha y hora actual como un Timestamp
        Timestamp datetime = new Timestamp(new Date().getTime());

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            // Establece los valores de los parametros en la consulta SQL
            pst.setInt(1, compra_id);
            pst.setDouble(2, precio_compra);
            pst.setInt(3, cantidad_compra);
            pst.setDouble(4, subtotal_compra);
            pst.setInt(5, producto_id);

            // Ejecuta la consulta SQL para insertar los detalles de la compra
            pst.execute();

            // Retorna 'true' si la inserción fue exitosa
            return true;

        } catch (SQLException e) {
            // Muestra un mensaje de error en caso de fallo al insertar los detalles de la compra
            JOptionPane.showMessageDialog(null, "Error al Registrar los detalles la compra" + e);
            // Retorna 'false' indicando que la inserción falló
            return false;
        }
    }

    //Obtener id de la compra
    public int compraId() {
        // Inicializa la variable 'id' con valor 0
        int id = 0;

        // Definición de la consulta SQL para obtener el ID máximo de la tabla 'compras'
        String query = "SELECT MAX(id) AS id FROM compras";

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            // Ejecuta la consulta SQL y guarda el resultado en 'rs'
            rs = pst.executeQuery();

            // Verifica si el resultado contiene alguna fila
            if (rs.next()) {
                // Obtiene el valor del campo 'id' del resultado y lo asigna a la variable 'id'
                id = rs.getInt("id");
            }
        } catch (SQLException e) {
            // Imprime el mensaje de error en la consola
            System.err.println(e.getMessage());

        }
        // Retorna el valor de 'id' obtenido de la consulta
        return id;
    }

    //Listar todas las compras realizada
    public List<Compras> listaComprasQuery() {

        List<Compras> lista_compra = new ArrayList<>();

        String query = "SELECT pu.id, pu.total, pu.created "
                + "FROM compras pu ORDER BY pu.id ASC";

        try {
            conn = cn.getConnection();
            pst = conn.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                Compras compra = new Compras();
                compra.setId(rs.getInt("id"));
                compra.setTotal(rs.getDouble("total"));
                compra.setCreated(rs.getString("created"));

                lista_compra.add(compra);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return lista_compra;
    }

    //Listar comprar para imprimir factura
    public List<Compras> listaDetallesComprasQuery(int id) {
        // Crea una lista para almacenar los objetos 'Compras'
        List<Compras> lista_detalles_compras = new ArrayList<>();

        // Definición de la consulta SQL para obtener los detalles de una compra específica
        String query = "SELECT pu.id, pu.created, SUM(pude.subtotal_compra) AS total_compra, pro.nombre AS nombre_producto, pude.precio_compra, pude.cantidad_compra, pude.subtotal_compra "
                + "FROM compras pu INNER JOIN detalles_compras pude ON pu.id = pude.compra_id "
                + "INNER JOIN productos pro ON pude.producto_id = pro.id WHERE pu.id = ? "
                + "GROUP BY pu.id, pu.created, pro.nombre, pude.precio_compra, pude.cantidad_compra, pude.subtotal_compra";

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la consulta SQL
            pst = conn.prepareStatement(query);
            // Establece el valor del parámetro 'id' en la consulta SQL
            pst.setInt(1, id);
            // Ejecuta la consulta SQL y guarda el resultado en 'rs'
            rs = pst.executeQuery();

            // Recorre cada fila del resultado
            while (rs.next()) {

                // Crea un nuevo objeto 'Compras'
                Compras compra = new Compras();
                // Establece los valores de las propiedades del objeto 'Compras' con los datos obtenidos de la consulta
                compra.setNombre_producto(rs.getString("nombre_producto"));
                compra.setCantidad_compra(rs.getInt("cantidad_compra"));
                compra.setPrecio_compra(rs.getDouble("precio_compra"));
                compra.setSubtotal_compra(rs.getDouble("subtotal_compra"));
                compra.setCreated(rs.getString("created"));

                // Añade el objeto 'Compras' a la lista
                lista_detalles_compras.add(compra);
            }
        } catch (SQLException e) {
            // Muestra un mensaje de error en caso de fallo al ejecutar la consulta
            JOptionPane.showMessageDialog(null, "Error al obtener los detalles de la compra: " + e.getMessage());
        }
        // Retorna la lista de objetos 'Compras'
        return lista_detalles_compras;
    }

    public String obtenerRolEmpleado(String nombreEmpleado) {
        String rol = rol_user;

        String query = "SELECT rol FROM administradora WHERE nombre = ?";

        try {
            conn = cn.getConnection();
            pst = conn.prepareStatement(query);
            pst.setString(1, nombreEmpleado);
            rs = pst.executeQuery();

            if (rs.next()) {
                rol_user = rs.getString("rol");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el rol del empleado: " + e.getMessage());
        }

        return rol;
    }

    public String obtenerNombreEmpleado(int empleado_id) {
        String nombre = nombre_user;

        String query = "SELECT nombre FROM administradora WHERE id = ?";

        try {
            conn = cn.getConnection();
            pst = conn.prepareStatement(query);
            pst.setInt(1, empleado_id);
            rs = pst.executeQuery();

            if (rs.next()) {
                nombre_user = rs.getString("nombre");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el nombre del empleado: " + e.getMessage());
        }

        return nombre;
    }

}
