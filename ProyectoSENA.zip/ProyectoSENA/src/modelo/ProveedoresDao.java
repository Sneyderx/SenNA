package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProveedoresDao {

    ConNectionMySQL cn = new ConNectionMySQL();
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    public boolean registrarProveedorQuery(Proveedor proveedor) {
        // Define la consulta SQL para insertar un nuevo proveedor en la tabla 'proveedor'
        String query = "INSERT INTO proveedor (id, nombre, telefono, correo, direccion, productos)"
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setInt(1, proveedor.getId());
            pst.setString(2, proveedor.getNombre());
            pst.setString(3, proveedor.getTelefono());
            pst.setString(4, proveedor.getCorreo());
            pst.setString(5, proveedor.getDireccion());
            pst.setString(6, proveedor.getProductos());
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al registrar al proveedor");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }

    public List listaProveedorQuery(String value) {
        // Crea una nueva lista para almacenar objetos de tipo Clientes
        List<Proveedor> lista_proveedor = new ArrayList();
        // Consulta SQL para seleccionar todos los registros de la tabla 'proveedor'
        String query = "SELECT * FROM proveedor";
        // Consulta SQL para buscar un proveedor por ID (filtrado por el valor proporcionado)
        String query_buscar_proveedor = "SELECT * FROM proveedor WHERE id LIKE '%" + value + "%'";
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Verifica si se proporcionó un valor para la búsqueda
            if (value.equalsIgnoreCase("")) {
                // Si no se proporcionó un valor, ejecuta la consulta para obtener todos los proveedores
                pst = conn.prepareStatement(query);
                rs = pst.executeQuery();
            } else {
                // Si se proporcionó un valor, ejecuta la consulta para buscar el proveedor por ID
                pst = conn.prepareStatement(query_buscar_proveedor);
                rs = pst.executeQuery();
            }

            // Itera a través de los resultados obtenidos de la consulta
            while (rs.next()) {
                // Crea un nuevo objeto Proveedor para almacenar los datos del registro actual
                Proveedor proveedor = new Proveedor();
                // Establece los valores de las propiedades del objeto Cliente con los datos del registro actual
                proveedor.setId(rs.getInt("id"));
                proveedor.setNombre(rs.getString("nombre"));
                proveedor.setTelefono(rs.getString("telefono"));
                proveedor.setCorreo(rs.getString("correo"));
                proveedor.setDireccion(rs.getString("direccion"));
                proveedor.setProductos(rs.getString("productos"));

                // Agrega el objeto Cliente a la lista
                lista_proveedor.add(proveedor);
            }
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente con los detalles del error
            JOptionPane.showMessageDialog(null, e.toString());
        }
        // Retorna la lista de clientes obtenida
        return lista_proveedor;
    }

    public boolean modificarProveedorQuery(Proveedor proveedor) {
        // Define la consulta SQL para actualizar los datos de un cliente en la tabla 'clientes'
        String query = "UPDATE proveedor SET nombre = ?, telefono = ?, correo = ?, direccion = ?, productos = ?"
                + "WHERE id = ?";

        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Establece los valores de los parámetros en la sentencia preparada
            pst.setString(1, proveedor.getNombre());
            pst.setString(2, proveedor.getTelefono());
            pst.setString(3, proveedor.getCorreo());
            pst.setString(4, proveedor.getDireccion());
            pst.setString(5, proveedor.getProductos());
            pst.setInt(6, proveedor.getId());
            // Ejecuta la sentencia SQL
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "Error al modificar los datos del proveedor");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }

    public boolean eliminarProveedorQuery(int id) {
        // Define la consulta SQL para eliminar un proveedor de la tabla 'proveedor' basado en su ID
        String query = "DELETE FROM proveedor WHERE id = " + id;
        try {
            // Establece la conexión con la base de datos
            conn = cn.getConnection();
            // Prepara la sentencia SQL con la consulta definida
            pst = conn.prepareStatement(query);
            // Ejecuta la sentencia SQL para eliminar el registro del proveedor
            pst.execute();
            // Retorna verdadero para indicar que la operación fue exitosa
            return true;
        } catch (SQLException e) {
            // En caso de error, muestra un mensaje de error en una ventana emergente
            JOptionPane.showMessageDialog(null, "No puede eliminar el proveedor");
            // Retorna falso para indicar que la operación falló
            return false;
        }
    }
    
}
