
package modelo;

public class Compras {
    private int id;
    private int codigo;
    private String nombre_producto;
    private int cantidad_compra;
    private double precio_compra;
    private double subtotal_compra;
    private String created;
    private double total;
    private String proveedor;
    private String compra;
    private int empleado_id;

    public Compras() {
    }

    public Compras(int id, int codigo, String nombre_producto, int cantidad_compra, double precio_compra, double subtotal_compra, String created, double total, String proveedor, String compra, int empleado_id) {
        this.id = id;
        this.codigo = codigo;
        this.nombre_producto = nombre_producto;
        this.cantidad_compra = cantidad_compra;
        this.precio_compra = precio_compra;
        this.subtotal_compra = subtotal_compra;
        this.created = created;
        this.total = total;
        this.proveedor = proveedor;
        this.compra = compra;
        this.empleado_id = empleado_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre_producto() {
        return nombre_producto;
    }

    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    public int getCantidad_compra() {
        return cantidad_compra;
    }

    public void setCantidad_compra(int cantidad_compra) {
        this.cantidad_compra = cantidad_compra;
    }

    public double getPrecio_compra() {
        return precio_compra;
    }

    public void setPrecio_compra(double precio_compra) {
        this.precio_compra = precio_compra;
    }

    public double getSubtotal_compra() {
        return subtotal_compra;
    }

    public void setSubtotal_compra(double subtotal_compra) {
        this.subtotal_compra = subtotal_compra;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getCompra() {
        return compra;
    }

    public void setCompra(String compra) {
        this.compra = compra;
    }

    public int getEmpleado_id() {
        return empleado_id;
    }

    public void setEmpleado_id(int empleado_id) {
        this.empleado_id = empleado_id;
    }
    
    
}
