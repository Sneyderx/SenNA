
package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static modelo.AdministradoraDao.rol_user;
import modelo.Clientes;
import modelo.ClientesDao;
import view.Sistema;


public class ControladorClientes implements ActionListener, MouseListener, KeyListener{
    private Clientes cliente;
    private ClientesDao clienteDao;
    private Sistema view;
    
    DefaultTableModel modelo = new DefaultTableModel();

    public ControladorClientes(Clientes cliente, ClientesDao clienteDao, Sistema view) {
        this.cliente = cliente;
        this.clienteDao = clienteDao;
        this.view = view;
        //Boton de Registrar Cliente
        this.view.btn_RegistrarCliente.addActionListener(this);
        this.view.btn_ModificarCliente.addActionListener(this);
        this.view.btn_EliminarCliente.addActionListener(this);
        this.view.btn_CancelarCliente.addActionListener(this);
        this.view.jLabelCliente.addMouseListener(this);
        this.view.txt_BuscarCliente.addKeyListener(this);
       
        this.view.TablaClientes.addMouseListener(this);
        
        
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == view.btn_RegistrarCliente){
            //Verificar si los campos estan vacios
            if(view.txt_IdentificacionCliente.getText().equals("")
                    || view.txt_NombreCliente.getText().equals("")
                    || view.txt_DireccionCliente.getText().equals("")
                    || view.txt_TelefonoCliente.getText().equals("")
                    || view.txt_CorreoCliente.getText().equals("")){
                
                    JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");            
            } else {
                cliente.setId(Integer.parseInt(view.txt_IdentificacionCliente.getText().trim()));
                cliente.setNombre(view.txt_NombreCliente.getText().trim());
                cliente.setDireccion(view.txt_DireccionCliente.getText().trim());
                cliente.setTelefono(view.txt_TelefonoCliente.getText().trim());
                cliente.setEmail(view.txt_CorreoCliente.getText().trim());
                
                if(clienteDao.registrarClienteQuery(cliente)){
                    limpiarTabla();
                    limpiarCampos();
                    listaCliente();
                    JOptionPane.showMessageDialog(null, "Cliente Registrado con exito");
                } else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al Registrar el Cliente");
                }
            }
        } else if(e.getSource() == view.btn_ModificarCliente){
            if(view.txt_IdentificacionCliente.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Selecciona una fila para continuar");
            } else{
                if(view.txt_IdentificacionCliente.getText().equals("")
                    || view.txt_NombreCliente.getText().equals("")
                    || view.txt_DireccionCliente.getText().equals("")
                    || view.txt_TelefonoCliente.getText().equals("")
                    || view.txt_CorreoCliente.getText().equals("")){
                    
                    JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
                } else{
                    cliente.setId(Integer.parseInt(view.txt_IdentificacionCliente.getText().trim()));
                    cliente.setNombre(view.txt_NombreCliente.getText().trim());
                    cliente.setDireccion(view.txt_DireccionCliente.getText().trim());
                    cliente.setTelefono(view.txt_TelefonoCliente.getText().trim());
                    cliente.setEmail(view.txt_CorreoCliente.getText().trim());
                    
                    if(clienteDao.modificarClienteQuery(cliente)){
                        limpiarTabla();
                        limpiarCampos();
                        listaCliente();
                        view.btn_RegistrarCliente.setEnabled(true);
                        
                        JOptionPane.showMessageDialog(null, "Datos del Cliente Modificado con Exito");
                    } else{
                        JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el cliente");
                    }
                }            
            }
        } else if(e.getSource() == view.btn_EliminarCliente){
            int row = view.TablaClientes.getSelectedRow();
            if(row == -1){
                JOptionPane.showMessageDialog(null, "Debes Seleccionar un cliente para eliminar");
            } else{
                int id = Integer.parseInt(view.TablaClientes.getValueAt(row, 0).toString());
                int pregunta = JOptionPane.showConfirmDialog(null, "¿Deseas Eliminar a este Cliente?");

                if (pregunta == 0 && clienteDao.eliminarClienteQuery(id) != false) {
                    limpiarTabla();
                    limpiarCampos();
                    view.btn_RegistrarCliente.setEnabled(true);
                    listaCliente();
                    JOptionPane.showMessageDialog(null, "Cliente Eliminado con Exito");
                }
            }
        } else if(e.getSource() == view.btn_CancelarCliente){
            view.btn_RegistrarCliente.setEnabled(true);
            limpiarCampos();
        }
    }
    
    
    //Listar Clientes
    public void listaCliente(){
        List<Clientes> lista = clienteDao.listaClienteQuery(view.txt_BuscarCliente.getText());
        modelo = (DefaultTableModel) view.TablaClientes.getModel();
        
        Object[] row = new Object[5];
        for(int i = 0; i < lista.size(); i++){
            row[0] = lista.get(i).getId();
            row[1] = lista.get(i).getNombre();
            row[2] = lista.get(i).getDireccion();
            row[3] = lista.get(i).getTelefono();
            row[4] = lista.get(i).getEmail();
            modelo.addRow(row);
        }
        
        view.TablaClientes.setModel(modelo);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == view.TablaClientes){
            int row = view.TablaClientes.rowAtPoint(e.getPoint());
            view.txt_IdentificacionCliente.setText(view.TablaClientes.getValueAt(row, 0).toString());
            view.txt_NombreCliente.setText(view.TablaClientes.getValueAt(row, 1).toString());
            view.txt_DireccionCliente.setText(view.TablaClientes.getValueAt(row, 2).toString());
            view.txt_TelefonoCliente.setText(view.TablaClientes.getValueAt(row, 3).toString());
            view.txt_CorreoCliente.setText(view.TablaClientes.getValueAt(row, 4).toString());
            
            view.btn_RegistrarCliente.setEnabled(false);
            view.txt_IdentificacionCliente.setEditable(false);
            
        } else if (e.getSource() == view.jLabelCliente) {
            String rol = rol_user;
            // Verificar si la condición de rol se evalúa correctamente
            if (rol != null && rol.trim().equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(2);
                limpiarTabla();
                limpiarCampos();
                listaCliente();
            } else {
                view.jTabbedPane1.setEnabledAt(2, false);
                view.jLabelCliente.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes Privilegios de Administrador para Acceder a esta vista");
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource() == view.txt_BuscarCliente){
            limpiarTabla();
            listaCliente();
        }
    }
    
    public void limpiarCampos(){
        view.txt_IdentificacionCliente.setText("");
        view.txt_IdentificacionCliente.setEditable(true);
        view.txt_NombreCliente.setText("");
        view.txt_DireccionCliente.setText("");
        view.txt_TelefonoCliente.setText("");
        view.txt_CorreoCliente.setText("");
    }
    
    public void limpiarTabla(){
        for(int i = 0; i < modelo.getRowCount(); i++){
            modelo.removeRow(i);
            i = i - 1;
        }
    }
}
