package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static modelo.AdministradoraDao.rol_user;
import modelo.DinamicaComboBox;
import modelo.Productos;
import modelo.ProductosDao;
import view.Sistema;

public class ControladorProductos implements ActionListener, MouseListener, KeyListener {
    
    private Productos producto;
    private ProductosDao productosDao;
    private Sistema view;
    String rol = rol_user;
    DefaultTableModel modelo = new DefaultTableModel();
    
    public ControladorProductos(Productos producto, ProductosDao productosDao, Sistema view) {
        this.producto = producto;
        this.productosDao = productosDao;
        this.view = view;
        this.view.btn_RegistrarProducto.addActionListener(this);
        this.view.btn_ActualizarProducto.addActionListener(this);
        this.view.btn_EliminarProducto.addActionListener(this);
        this.view.btn_CancelarProducto.addActionListener(this);
        this.view.Tabla_Producto.addMouseListener(this);
        this.view.txt_BuscarProducto.addKeyListener(this);
        this.view.jLabelProducto.addMouseListener(this);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btn_RegistrarProducto) {
            if (view.txt_ProductoCodigo.getText().equals("")
                    || view.txt_NombreProducto.getText().equals("")
                    || view.txt_Descripcion.getText().equals("")
                    || view.txt_Cantidades.getText().equals("")
                    || view.txt_PrecioVenta.getText().equals("")
                    || view.cmb_CategoriaProducto.getSelectedItem().toString().equals("")) {
                
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            } else {
                producto.setCodigo(Integer.parseInt(view.txt_ProductoCodigo.getText()));
                producto.setNombre(view.txt_NombreProducto.getText().trim());
                producto.setDescripcion(view.txt_Descripcion.getText().trim());
                producto.setCantidad_Producto(Integer.parseInt(view.txt_Cantidades.getText()));
                producto.setPrecio_Unitario(Double.parseDouble(view.txt_PrecioVenta.getText()));
                DinamicaComboBox categoria_id = (DinamicaComboBox) view.cmb_CategoriaProducto.getSelectedItem();
                producto.setCategoria_id(categoria_id.getId());
                
                if (productosDao.registrarProductoQuery(producto)) {
                    limpiarTabla();
                    limpiarCampos();
                    listarProductos();
                    JOptionPane.showMessageDialog(null, "Producto Registrado con Exito");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha Ocurrido un Error al Registrar el Producto");
                    
                }
            }
        } else if (e.getSource() == view.btn_ActualizarProducto) {
            if (view.txt_ProductoCodigo.getText().equals("")
                    || view.txt_NombreProducto.getText().equals("")
                    || view.txt_Descripcion.getText().equals("")
                    || view.txt_Cantidades.getText().equals("")
                    || view.txt_PrecioVenta.getText().equals("")
                    || view.cmb_CategoriaProducto.getSelectedItem().toString().equals("")) {
                
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            } else {
                producto.setCodigo(Integer.parseInt(view.txt_ProductoCodigo.getText()));
                producto.setNombre(view.txt_NombreProducto.getText().trim());
                producto.setDescripcion(view.txt_Descripcion.getText().trim());
                producto.setCantidad_Producto(Integer.parseInt(view.txt_Cantidades.getText()));
                producto.setPrecio_Unitario(Double.parseDouble(view.txt_PrecioVenta.getText()));
                DinamicaComboBox categoria_id = (DinamicaComboBox) view.cmb_CategoriaProducto.getSelectedItem();
                producto.setCategoria_id(categoria_id.getId());
                producto.setId(Integer.parseInt(view.txt_IdProducto.getText()));
                
                if (productosDao.modificarProductoQuery(producto)) {
                    limpiarTabla();
                    limpiarCampos();
                    listarProductos();
                    JOptionPane.showMessageDialog(null, "Datos del Producto Modificados con Exito");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha Ocurrido un Error al Modificar los Datos del Producto");
                }
            }
        } else if (e.getSource() == view.btn_EliminarProducto) {
            int row = view.Tabla_Producto.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar un Producto para Eliminar");
            } else {
                int id = Integer.parseInt(view.Tabla_Producto.getValueAt(row, 0).toString());
                int pregunta = JOptionPane.showConfirmDialog(null, "¿Deseas Eliminar a este Producto?");
                
                if (pregunta == 0 && productosDao.eliminarProductoQuery(id) != false) {
                    limpiarTabla();
                    limpiarCampos();
                    view.btn_RegistrarProducto.setEnabled(true);
                    listarProductos();
                    JOptionPane.showMessageDialog(null, "Producto Eliminado con Exito");
                }
            }
        } else if (e.getSource() == view.btn_CancelarProducto) {
            limpiarCampos();
            view.btn_RegistrarProducto.setEnabled(true);
        }
    }
    
    public void listarProductos() {
        if (rol.equals("Administrador")) {
            List<Productos> lista = productosDao.listaProductosQuery(view.txt_BuscarProducto.getText());
            modelo = (DefaultTableModel) view.Tabla_Producto.getModel();
            Object[] row = new Object[8];
            for (int i = 0; i < lista.size(); i++) {
                row[0] = lista.get(i).getId();
                row[1] = lista.get(i).getCodigo();
                row[2] = lista.get(i).getNombre();
                row[3] = lista.get(i).getCantidad_Producto();
                row[4] = lista.get(i).getNombre_categoria();
                row[5] = lista.get(i).getDescripcion();
                row[6] = lista.get(i).getPrecio_Unitario();
                modelo.addRow(row);
            }
            view.Tabla_Producto.setModel(modelo);
            
        }
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == view.Tabla_Producto) {
            int row = view.Tabla_Producto.rowAtPoint(e.getPoint());
            view.txt_IdProducto.setText(view.Tabla_Producto.getValueAt(row, 0).toString());
            producto = productosDao.buscarProductoQuery(Integer.parseInt(view.txt_IdProducto.getText()));
            view.txt_ProductoCodigo.setText("" + producto.getCodigo());
            view.txt_NombreProducto.setText(producto.getNombre());
            view.txt_Descripcion.setText(producto.getDescripcion());
            view.txt_PrecioVenta.setText("" + producto.getPrecio_Unitario());
            view.cmb_CategoriaProducto.setSelectedItem(new DinamicaComboBox(producto.getCategoria_id(), producto.getNombre_categoria()));
            view.btn_RegistrarProducto.setEnabled(false);
            
        } else if (e.getSource() == view.jLabelProducto) {
            String rol = rol_user;
            // Verificar si la condición de rol se evalúa correctamente
            if (rol != null && rol.trim().equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(1);
                limpiarTabla();
                limpiarCampos();
                listarProductos();
            } else {
                view.jTabbedPane1.setEnabledAt(1, false);
                view.jLabelProducto.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes Privilegios de Administrador para Acceder a esta vista");
            }
        }
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }
    
    @Override
    public void mouseEntered(MouseEvent e) {
        
    }
    
    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == view.txt_BuscarProducto) {
            limpiarTabla();
            listarProductos();
        }
    }
    
    public void limpiarCampos() {
        view.txt_IdProducto.setText("");
        view.txt_ProductoCodigo.setText("");
        view.txt_Cantidades.setText("");
        view.txt_NombreProducto.setText("");
        view.txt_Descripcion.setText("");
        view.txt_PrecioVenta.setText("");
    }
    
    public void limpiarTabla() {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }
    }
}
