
package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static modelo.AdministradoraDao.rol_user;
import modelo.Categorias;
import modelo.CategoriasDao;
import modelo.DinamicaComboBox;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;
import view.Sistema;

public class ControladorCategorias implements ActionListener, MouseListener, KeyListener {

    private Categorias categoria;
    private CategoriasDao categoriasDao;
    private Sistema view;
    DefaultTableModel modelo = new DefaultTableModel();

    public ControladorCategorias(Categorias categoria, CategoriasDao categoriasDao, Sistema view) {
        this.categoria = categoria;
        this.categoriasDao = categoriasDao;
        this.view = view;
        this.view.btn_RegistrarCategoria.addActionListener(this);
        this.view.btn_ModificarCategoria.addActionListener(this);
        this.view.btn_EliminarCategoria.addActionListener(this);
        this.view.btn_CancelarCategoria.addActionListener(this);
        this.view.TablaCategoria.addMouseListener(this);
        this.view.txt_BuscarCategoria.addKeyListener(this);
        this.view.jLabelCategorias.addMouseListener(this);
        getNombreCategoria();
        AutoCompleteDecorator.decorate(view.cmb_CategoriaProducto);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btn_RegistrarCategoria) {
            if (view.txt_NombreCategoria.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            } else {
                categoria.setNombre(view.txt_NombreCategoria.getText().trim());

                if (categoriasDao.registrarCategoriasQuery(categoria)) {
                    JOptionPane.showMessageDialog(null, "Categoria Registrada con exito");
                    limpiarTabla();
                    limpiarCampos();
                    listarCategorias();
                } else {
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al registrar la categoria");
                }
            }
        } else if (e.getSource() == view.btn_ModificarCategoria) {
            if (view.txt_IdCategoria.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Selecciona una fila para continuar");

            } else{
                if(view.txt_IdCategoria.getText().equals("")
                   || view.txt_NombreCategoria.getText().equals("")){
                   JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");

                } else{
                    categoria.setId(Integer.parseInt(view.txt_IdCategoria.getText()));
                    categoria.setNombre(view.txt_NombreCategoria.getText().trim());
                    
                    if(categoriasDao.modificarCategoriasQuery(categoria)){
                        JOptionPane.showMessageDialog(null, "Categoria modificada con exito");
                        limpiarTabla();
                        limpiarCampos();
                        listarCategorias();
                    }
                }
            }
        } else if(e.getSource() == view.btn_EliminarCategoria){
            int row = view.TablaCategoria.getSelectedRow();
            if(row == -1){
                JOptionPane.showMessageDialog(null, "Debes Seleccionar una Categoria para Eliminar");
            } else{
                int id = Integer.parseInt(view.TablaCategoria.getValueAt(row, 0).toString());
                int pregunta = JOptionPane.showConfirmDialog(null, "¿Deseas Eliminar esta Categoria?");

                if(pregunta == 0 && categoriasDao.eliminarCategoriasQuery(id) != false){
                    limpiarTabla();
                    limpiarCampos();
                    view.btn_RegistrarCategoria.setEnabled(true);
                    listarCategorias();
                    JOptionPane.showMessageDialog(null, "Categoria Eliminada con exito");
                }
            }
        } else if(e.getSource() == view.btn_CancelarCategoria){
            limpiarCampos();
            view.btn_RegistrarCategoria.setEnabled(true);
        }
    }

    public void listarCategorias() {
        List<Categorias> lista = categoriasDao.listaCategoriasQuery(view.txt_BuscarCategoria.getText());
        modelo = (DefaultTableModel) view.TablaCategoria.getModel();
        Object[] row = new Object[2];
        for (int i = 0; i < lista.size(); i++) {
            row[0] = lista.get(i).getId();
            row[1] = lista.get(i).getNombre();
            modelo.addRow(row);
        }
        view.TablaCategoria.setModel(modelo);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == view.TablaCategoria) {
            int row = view.TablaCategoria.rowAtPoint(e.getPoint());
            view.txt_IdCategoria.setText(view.TablaCategoria.getValueAt(row, 0).toString());
            view.txt_NombreCategoria.setText(view.TablaCategoria.getValueAt(row, 1).toString());

            view.btn_RegistrarCategoria.setEnabled(false);

        } else if (e.getSource() == view.jLabelCategorias) {

            String rol = rol_user;
            // Verificar si la condición de rol se evalúa correctamente
            if (rol != null && rol.trim().equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(4);
                limpiarTabla();
                limpiarCampos();
                listarCategorias();
            } else {
                view.jTabbedPane1.setEnabledAt(4, false);
                view.jLabelCategorias.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes Privilegios de Administrador para Acceder a esta vista");
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == view.txt_BuscarCategoria) {
            limpiarTabla();
            listarCategorias();
        }
    }

    public void limpiarCampos() {
        view.txt_usuarioId.setText("");
        view.txt_NombreCategoria.setText("");
        view.txt_usuarioId.setEditable(true);
    }

    public void limpiarTabla() {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }
    }

    //Metodo para mostrar el nombre de las categorias
    public void getNombreCategoria(){
        List<Categorias> lista = categoriasDao.listaCategoriasQuery(view.txt_BuscarCategoria.getText());
        for (int i = 0; i<lista.size(); i++){
            int id = lista.get(i).getId();
            String nombre = lista.get(i).getNombre();
            view.cmb_CategoriaProducto.addItem(new DinamicaComboBox(id, nombre));
        }
    }
}
