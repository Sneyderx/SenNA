package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Administradora;
import modelo.AdministradoraDao;
import static modelo.AdministradoraDao.id_user;
import static modelo.AdministradoraDao.rol_user;
import modelo.DinamicaComboBox;
import view.Sistema;

public class ControladorUsuario implements ActionListener, MouseListener, KeyListener {

    private Administradora administradora;
    private AdministradoraDao administradoraDao;
    private Sistema view;
    DefaultTableModel modelo = new DefaultTableModel();

    public ControladorUsuario(Administradora administradora, AdministradoraDao administradoraDao, Sistema view) {
        this.administradora = administradora;
        this.administradoraDao = administradoraDao;
        this.view = view;

        administradoraDao.obtenerRolUser();

        //Boton de Registrar Usuario
        this.view.btn_RegistrarUsuario.addActionListener(this);
        this.view.btn_modificarUsuario.addActionListener(this);
        this.view.btn_eliminarUsuario.addActionListener(this);
        this.view.btn_cancelarUsuario.addActionListener(this);
        this.view.btn_ModificarPerfil.addActionListener(this);
        this.view.jLabelInfo.addMouseListener(this);
        this.view.TablaUsuarios.addMouseListener(this);
        this.view.txt_BuscarUsuario.addKeyListener(this);
        this.view.jLabelAjustes.addMouseListener(this);

    }

    //Registrar Usuario
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == view.btn_RegistrarUsuario) {
            //Verificar si los campos estan vacios
            if (view.txt_usuarioId.getText().equals("")
                    || view.txt_nombreCompleto.getText().equals("")
                    || view.txt_nombreUsuario.getText().equals("")
                    || view.txt_direccionUsuario.getText().equals("")
                    || view.txt_telefonoUsuario.getText().equals("")
                    || view.txt_correoUsuario.getText().equals("")
                    || view.cmb_rol.getSelectedItem().toString().equals("")
                    || String.valueOf(view.txt_contraseñaUsuario.getPassword()).equals("")) {

                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");

            } else {
                //Realizar la insercion
                administradora.setId(Integer.parseInt(view.txt_usuarioId.getText().trim()));
                administradora.setNombre(view.txt_nombreCompleto.getText().trim());
                administradora.setUsuario(view.txt_nombreUsuario.getText().trim());
                administradora.setDireccion(view.txt_direccionUsuario.getText().trim());
                administradora.setTelefono(view.txt_telefonoUsuario.getText().trim());
                administradora.setEmail(view.txt_correoUsuario.getText().trim());
                administradora.setContraseña(String.valueOf(view.txt_contraseñaUsuario.getPassword()));
                administradora.setRol(view.cmb_rol.getSelectedItem().toString());

                if (administradoraDao.registrarAdministradoraQuery(administradora)) {
                    limpiarTabla();
                    limpiarCampos();
                    listaUsuarios();
                    JOptionPane.showMessageDialog(null, "Usuario Registrado con exito");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al registrar el Usuario");
                }
            }
        } else if (e.getSource() == view.btn_modificarUsuario) {
            if (view.txt_usuarioId.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Selecciona una fila para continuar");
            } else {
                //Verifica si los campos estan vacios
                if (view.txt_usuarioId.getText().equals("")
                        || view.txt_nombreCompleto.getText().equals("")
                        || view.cmb_rol.getSelectedItem().toString().equals("")) {

                    JOptionPane.showMessageDialog(null, "Todos los Campos son obligatorios");
                } else {
                    //Realizar la insercion
                    administradora.setId(Integer.parseInt(view.txt_usuarioId.getText().trim()));
                    administradora.setNombre(view.txt_nombreCompleto.getText().trim());
                    administradora.setUsuario(view.txt_nombreUsuario.getText().trim());
                    administradora.setDireccion(view.txt_direccionUsuario.getText().trim());
                    administradora.setTelefono(view.txt_telefonoUsuario.getText().trim());
                    administradora.setEmail(view.txt_correoUsuario.getText().trim());
                    administradora.setContraseña(String.valueOf(view.txt_contraseñaUsuario.getPassword()));
                    administradora.setRol(view.cmb_rol.getSelectedItem().toString());

                    if (administradoraDao.modificarAdministradoraQuery(administradora)) {
                        limpiarTabla();
                        limpiarCampos();
                        listaUsuarios();
                        view.btn_RegistrarUsuario.setEnabled(true);
                        JOptionPane.showMessageDialog(null, "Datos Modificados Correctamente");
                    } else {
                        JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar al Usuario");
                    }
                }
            }
        } else if (e.getSource() == view.btn_eliminarUsuario) {
            int row = view.TablaUsuarios.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar un Usuario para Eliminar");
            } else if (view.TablaUsuarios.getValueAt(row, 0).equals(id_user)) {
                JOptionPane.showMessageDialog(null, "No puede Eliminar al Usuario Autenticado");
            } else {
                int id = Integer.parseInt(view.TablaUsuarios.getValueAt(row, 0).toString());
                int pregunta = JOptionPane.showConfirmDialog(null, "¿Deseas Eliminar a este Usuario?");

                if (pregunta == 0 && administradoraDao.eliminarUsuarioQuery(id) != false) {
                    limpiarTabla();
                    limpiarCampos();
                    view.btn_RegistrarUsuario.setEnabled(true);
                    view.txt_contraseñaUsuario.setEnabled(true);
                    listaUsuarios();
                    JOptionPane.showMessageDialog(null, "Empleado Eliminado con Exito");
                }
            }
        } else if (e.getSource() == view.btn_cancelarUsuario) {
            limpiarCampos();
            view.btn_RegistrarUsuario.setEnabled(true);
            view.txt_contraseñaUsuario.setEnabled(true);
            view.txt_usuarioId.setEnabled(true);
        } else if (e.getSource() == view.btn_ModificarPerfil) {
            //Recolectar Informacion de las cajas de Contraseña
            String contraseña = String.valueOf(view.txt_ModificarContraseña.getPassword());
            String confirmar_contraseña = String.valueOf(view.txt_ConfirmarContraseña.getPassword());
            //Verificar si las cajas de texto estan vacias
            if (!contraseña.equals("") && !confirmar_contraseña.equals("")) {
                //Verificar si las contraseñas son iguales
                if (contraseña.equals(confirmar_contraseña)) {
                    administradora.setContraseña(String.valueOf(view.txt_ModificarContraseña.getPassword()));

                    if (administradoraDao.cambiarContraseña(administradora) != false) {
                        JOptionPane.showMessageDialog(null, "Contraseña Modificada con Exito");
                    } else {
                        JOptionPane.showMessageDialog(null, "Ha Ocurrido un Error al Modificar la Contraseña");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Las Contraseñas no Coinciden");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Todos los Campos son Obligatorios");
            }
        }
    }

    //Listar Usuarios
    public void listaUsuarios() {
        List<Administradora> lista = administradoraDao.listaAdministradoraQuery(view.txt_BuscarUsuario.getText());
        modelo = (DefaultTableModel) view.TablaUsuarios.getModel();

        Object[] row = new Object[7];
        for (int i = 0; i < lista.size(); i++) {
            row[0] = lista.get(i).getId();
            row[1] = lista.get(i).getNombre();
            row[2] = lista.get(i).getUsuario();
            row[3] = lista.get(i).getDireccion();
            row[4] = lista.get(i).getTelefono();
            row[5] = lista.get(i).getEmail();
            row[6] = lista.get(i).getRol();
            modelo.addRow(row);
        }

        view.TablaUsuarios.setModel(modelo);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // Actualizar el valor de rol antes de usarlo
        String rol = rol_user;

        if (e.getSource() == view.TablaUsuarios) {
            //En que fila se ha hecho click
            int row = view.TablaUsuarios.rowAtPoint(e.getPoint());

            if (row >= 0) { // Verifica si se ha seleccionado una fila válida
                view.txt_usuarioId.setText(view.TablaUsuarios.getValueAt(row, 0).toString());
                view.txt_nombreCompleto.setText(view.TablaUsuarios.getValueAt(row, 1).toString());
                view.txt_nombreUsuario.setText(view.TablaUsuarios.getValueAt(row, 2).toString());
                view.txt_direccionUsuario.setText(view.TablaUsuarios.getValueAt(row, 3).toString());
                view.txt_telefonoUsuario.setText(view.TablaUsuarios.getValueAt(row, 4).toString());
                view.txt_correoUsuario.setText(view.TablaUsuarios.getValueAt(row, 5).toString());
                view.cmb_rol.setSelectedItem(view.TablaUsuarios.getValueAt(row, 6).toString());

                //Deshabilitar
                view.txt_usuarioId.setEditable(false);
                view.txt_contraseñaUsuario.setEnabled(false);
                view.btn_RegistrarUsuario.setEnabled(false);
            }
        } else if (e.getSource() == view.jLabelInfo) {
            // Verificar si la condición de rol se evalúa correctamente
//            System.out.println("Condición de rol: " + (rol != null && rol.trim().equals("Administrador")));

            if (rol != null && rol.trim().equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(7);
                limpiarTabla();
                limpiarCampos();
                listaUsuarios();
            } else {
                view.jTabbedPane1.setEnabledAt(7, false);
                view.jLabelInfo.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes Privilegios de Administrador para Acceder a esta vista");
            }
        } else if (e.getSource() == view.jLabelAjustes) {  
            view.jTabbedPane1.setSelectedIndex(6);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == view.txt_BuscarUsuario) {
            limpiarTabla();
            listaUsuarios();
        }
    }

    public void limpiarCampos() {
        view.txt_usuarioId.setText("");
        view.txt_usuarioId.setEditable(true);
        view.txt_nombreCompleto.setText("");
        view.txt_nombreUsuario.setText("");
        view.txt_direccionUsuario.setText("");
        view.txt_telefonoUsuario.setText("");
        view.txt_correoUsuario.setText("");
        view.txt_contraseñaUsuario.setText("");
        view.cmb_rol.setSelectedIndex(0);
    }

    public void limpiarTabla() {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }
    }

}
