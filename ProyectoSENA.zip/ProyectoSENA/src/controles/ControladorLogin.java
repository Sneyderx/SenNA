package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Administradora;
import modelo.AdministradoraDao;
import view.InicioSesion;
import view.Sistema;

public class ControladorLogin implements ActionListener {

    private Administradora administradora;
    private AdministradoraDao administradora_dao;
    private InicioSesion login_view;

    public ControladorLogin(Administradora administradora, AdministradoraDao administradora_dao, InicioSesion login_view) {
        this.administradora = administradora;
        this.administradora_dao = administradora_dao;
        this.login_view = login_view;
        this.login_view.btn_enter.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Obtener los datos introducidos por el usuario en las cajas de texto
        String user = login_view.txt_Usuario.getText().trim();
        String pass = String.valueOf(login_view.txt_Contraseña.getPassword());

        if (e.getSource() == login_view.btn_enter) {
            //Validar que los campos no esten vacios
            if (!user.equals("") || !pass.equals("")) {
                //Pasar los parametros al metodo Login
                administradora = administradora_dao.loginQuery(user, pass);
                //Verificar la existencia del usuario
                if (administradora.getUsuario() != null) {
                    String rol = administradora.getRol();
                    if ("Administradora".equals(rol)) {
                        Sistema admin = new Sistema();
                        admin.setVisible(true);
                    } else {
                        Sistema aux = new Sistema();
                        aux.setVisible(true);
                    }
                    this.login_view.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o Contraseña Incorrecto");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Los Campos estan Vacios");
            }
        }
    }

}
