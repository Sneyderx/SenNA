
package controles;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import static modelo.AdministradoraDao.*;
import view.Sistema;

public class AjustesControladores implements MouseListener {

    private Sistema vista;
    
    public AjustesControladores(Sistema vista){
        this.vista = vista;
        this.vista.jLabelProducto.addMouseListener(this);
        this.vista.jLabelCompra.addMouseListener(this);
        this.vista.jLabelCliente.addMouseListener(this);
        this.vista.jLabelProveedor.addMouseListener(this);
        this.vista.jLabelCategorias.addMouseListener(this);
        this.vista.jLabelReportes.addMouseListener(this);
        this.vista.jLabelAjustes.addMouseListener(this);
        this.vista.jLabelInfo.addMouseListener(this);
        perfil();
    }
    
    //Asignar el perfil del usuario
    public void perfil(){
        this.vista.txt_IdPerfil.setText("" + id_user);
        this.vista.txt_NombrePerfil.setText(nombre_user);
        this.vista.txt_DireccionPerfil.setText(direccion_user);
        this.vista.txt_TelefonoPerfil.setText(telefono_user);
        this.vista.txt_CorreoPerfil.setText(email_user);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

        //Codigo para ajustar el color cuando el mouse se posiciona por encima de cada label o panel
        if(e.getSource() == vista.jLabelCompra){
            vista.jPanelCompra.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelProducto){
            vista.jPanelProducto.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelCliente){
            vista.jPanelCliente.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelProveedor){
            vista.jPanelProveedor.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelCategorias){
            vista.jPanelCategorias.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelReportes){
            vista.jPanelReportes.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelAjustes){
            vista.jPanelAjustes.setBackground(new Color(212,99,245));
        } else if(e.getSource() == vista.jLabelInfo){
            vista.jPanelInfo.setBackground(new Color(212,99,245));
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {

        //Codigo para configurar el color del mouse cuando el usuario deje de situarse sobre el panel o label
        if(e.getSource() == vista.jLabelCompra){
            vista.jPanelCompra.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelProducto){
            vista.jPanelProducto.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelCliente){
            vista.jPanelCliente.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelProveedor){
            vista.jPanelProveedor.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelCategorias){
            vista.jPanelCategorias.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelReportes){
            vista.jPanelReportes.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelAjustes){
            vista.jPanelAjustes.setBackground(new Color(129,1,137));
        } else if(e.getSource() == vista.jLabelInfo){
            vista.jPanelInfo.setBackground(new Color(129,1,137));
        }
    }
    
}
