package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static modelo.AdministradoraDao.id_user;
import static modelo.AdministradoraDao.rol_user;
import modelo.Compras;
import modelo.ComprasDao;
import modelo.Productos;
import modelo.ProductosDao;
import view.Imprimir;
import view.Sistema;

public class ControladorCompras implements KeyListener, ActionListener, MouseListener {

    private Compras compra;
    private ComprasDao comprasDao;
    private Sistema view;
    private int getIdUsuario = 0;
    private int item = 0;
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel temp;

    Productos producto = new Productos();
    ProductosDao productosDao = new ProductosDao();
    String rol = rol_user;

    public ControladorCompras(Compras compra, ComprasDao comprasDao, Sistema view) {
        this.compra = compra;
        this.comprasDao = comprasDao;
        this.view = view;
        this.view.txt_CompraCodigoProducto.addKeyListener(this);
        this.view.txt_CompraPrecioProducto.addKeyListener(this);
        this.view.btn_AgregarCompraProducto.addActionListener(this);
        this.view.btn_CompraProducto.addActionListener(this);
        this.view.btn_EliminarCompraProducto.addActionListener(this);
        this.temp = (DefaultTableModel) this.view.TablaComprarProducto.getModel();  // inicializar this.temp
        this.view.btn_CancelarCompraProducto.addActionListener(this);
        this.view.jLabelCompra.addMouseListener(this);
        this.view.jLabelReportes.addMouseListener(this);
        this.view.jLabelProveedor.addMouseListener(this);

    }

    @Override

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btn_AgregarCompraProducto) {

            int cantidad = Integer.parseInt(view.txt_CompraCantidadProducto.getText());
            String nombre_producto = view.txt_CompraNombreProducto.getText();
            double precio = Double.parseDouble(view.txt_CompraPrecioProducto.getText());
            int id_compra = Integer.parseInt(view.txt_CompraIdProducto.getText());

            if (cantidad > 0) {
                DefaultTableModel temp = (DefaultTableModel) view.TablaComprarProducto.getModel();
                for (int i = 0; i < view.TablaComprarProducto.getRowCount(); i++) {
                    if (view.TablaComprarProducto.getValueAt(i, 1).equals(nombre_producto)) {
                        JOptionPane.showMessageDialog(null, "El Producto ya está registrado en la tabla de compras");
                        return;
                    }
                }

                ArrayList<Object> lista = new ArrayList<>();
                int item = 1;
                lista.add(item);
                lista.add(id_compra);
                lista.add(nombre_producto);
                lista.add(cantidad);
                lista.add(precio);
                lista.add(cantidad * precio);

                Object[] obj = new Object[6];
                obj[0] = lista.get(0);  // Item
                obj[1] = lista.get(1);  // ID Compra
                obj[2] = lista.get(2);  // Nombre Producto
                obj[3] = lista.get(3);  // Cantidad
                obj[4] = lista.get(4);  // Precio
                obj[5] = lista.get(5);  // Total
                temp.addRow(obj);
                view.TablaComprarProducto.setModel(temp);

                limpiarCampos();
                view.txt_CompraCodigoProducto.requestFocus();
                calcularTotalPagar();
            }
        } else if (e.getSource() == view.btn_CompraProducto) {
            insertarCompra();
        } else if (e.getSource() == view.btn_EliminarCompraProducto) {
            modelo = (DefaultTableModel) view.TablaComprarProducto.getModel();
            modelo.removeRow(view.TablaComprarProducto.getSelectedRow());
            calcularTotalPagar();
            view.txt_CompraCodigoProducto.requestFocus();
        } else if (e.getSource() == view.btn_CancelarCompraProducto) {
            limpiarTabla();
            limpiarCampos();
        }
    }

    private void insertarCompra() {
        double total = Double.parseDouble(view.txt_CompraTotalPagarProducto.getText());
        int empleado_id = id_user;

        if (comprasDao.registrarCompraQuery(empleado_id, total)) {
            int compra_id = comprasDao.compraId();
            for (int i = 0; i < view.TablaComprarProducto.getRowCount(); i++) {
                int producto_id = Integer.parseInt(view.TablaComprarProducto.getValueAt(i, 1).toString());
                int cantidad_compra = Integer.parseInt(view.TablaComprarProducto.getValueAt(i, 3).toString());
                double precio_compra = Double.parseDouble(view.TablaComprarProducto.getValueAt(i, 4).toString());
                double subtotal_compra = precio_compra * cantidad_compra;

                if (!productosDao.actualizarStock(cantidad_compra, producto_id)) {

                    return;
                }
                comprasDao.registrarDetallesCompraQuery(compra_id, precio_compra, cantidad_compra, subtotal_compra, producto_id);
            }

            limpiarTabla();
            listaTodasCompras();  // Actualizar la tabla de reportes después de insertar una compra
            JOptionPane.showMessageDialog(null, "Compra Realizada con Éxito");
            limpiarCampos();
            Imprimir imprimir = new Imprimir(compra_id);
            imprimir.setVisible(true);

        } else {
            JOptionPane.showMessageDialog(null, "Error al realizar la compra");
        }
    }

    public void listaTodasCompras() {
        if (rol.equals("Administrador")) {
            List<Compras> lista = comprasDao.listaComprasQuery();
            modelo = (DefaultTableModel) view.TablaReportes.getModel();
            modelo.setRowCount(0);
            for (int i = 0; i < lista.size(); i++) {
                Object[] row = new Object[3];
                row[0] = lista.get(i).getId();
                row[1] = lista.get(i).getTotal();
                row[2] = lista.get(i).getCreated();
                modelo.addRow(row);

            }
            view.TablaReportes.setModel(modelo);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getSource() == view.txt_CompraCodigoProducto) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                if (view.txt_CompraCodigoProducto.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Ingresa el Codigo del Producto a Comprar");
                } else {
                    int id = Integer.parseInt(view.txt_CompraCodigoProducto.getText());
                    producto = productosDao.buscarCodigoQuery(id);
                    view.txt_CompraNombreProducto.setText(producto.getNombre());
                    view.txt_CompraIdProducto.setText("" + producto.getId());
                    view.txt_CompraCantidadProducto.requestFocus();
                }
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == view.txt_CompraPrecioProducto) {
            int cantidad;
            double precio = 0.0;

            if (view.txt_CompraCantidadProducto.getText().equals("")) {
                cantidad = 1;
                view.txt_CompraPrecioProducto.setText("" + precio);
            } else {
                cantidad = Integer.parseInt(view.txt_CompraCantidadProducto.getText());
                if (!view.txt_CompraPrecioProducto.getText().isEmpty()) {
                    precio = Double.parseDouble(view.txt_CompraPrecioProducto.getText());
                    view.txt_CompraSubTotalProducto.setText("" + cantidad * precio);
                }
            }
        }
    }

    public void limpiarCampos() {
        view.txt_CompraNombreProducto.setText("");
        view.txt_CompraPrecioProducto.setText("");
        view.txt_CompraCantidadProducto.setText("");
        view.txt_CompraCodigoProducto.setText("");
        view.txt_CompraSubTotalProducto.setText("");
        view.txt_CompraIdProducto.setText("");
        view.txt_CompraTotalPagarProducto.setText("");
    }

    public void calcularTotalPagar() {
        double total = 0.00;
        int numRow = view.TablaComprarProducto.getRowCount();

        for (int i = 0; i < numRow; i++) {
            total = total + Double.parseDouble(String.valueOf(view.TablaComprarProducto.getValueAt(i, 5)));
        }
        view.txt_CompraTotalPagarProducto.setText("" + total);
    }

    public void limpiarTabla() {
        if (this.temp != null) {
            int rowCount = this.temp.getRowCount();
            for (int i = rowCount - 1; i >= 0; i--) {
                this.temp.removeRow(i);
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == view.jLabelCompra) {  
            view.jTabbedPane1.setSelectedIndex(0);
            limpiarTablaCompras();
        } else if (e.getSource() == view.jLabelReportes) {
            if (rol.equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(5);
                limpiarTablaCompras();
            } else {
                view.jTabbedPane1.setEnabledAt(5, false);
                view.jLabelReportes.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes pivilegios de Administrador para ingresar a esta vista");
            }
        } else if (e.getSource() == view.jLabelProveedor) {
            if (rol.equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(3);
            } else {
                view.jTabbedPane1.setEnabledAt(3, false);
                view.jLabelProveedor.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes pivilegios de Administrador para ingresar a esta vista");
            }
        }
    }

    public void limpiarTablaCompras() {
        DefaultTableModel modelo = (DefaultTableModel) view.TablaReportes.getModel();
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }

//    public void limpiarTablaCompras() {
//        for (int i = 0; i < modelo.getRowCount(); i++) {
//            modelo.removeRow(i);
//            i = i - 1;
//        }
//    }
    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
