package controles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static modelo.AdministradoraDao.rol_user;
import modelo.Proveedor;
import modelo.ProveedoresDao;
import view.Sistema;

public class ControladorProveedor implements ActionListener, MouseListener, KeyListener {

    private Proveedor proveedor;
    private ProveedoresDao proveedoresDao;
    private Sistema view;

    DefaultTableModel modelo = new DefaultTableModel();

    public ControladorProveedor(Proveedor proveedor, ProveedoresDao proveedoresDao, Sistema view) {
        this.proveedor = proveedor;
        this.proveedoresDao = proveedoresDao;
        this.view = view;
        this.view.btn_RegistrarProveedor.addActionListener(this);
        this.view.btn_ModificarProveedor.addActionListener(this);
        this.view.btn_EliminarProveedor.addActionListener(this);
        this.view.btn_CancelarProveedor.addActionListener(this);
        this.view.jLabelProveedor.addMouseListener(this);
        this.view.txt_BuscarProveedor.addKeyListener(this);
        this.view.TablaProveedor.addMouseListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btn_RegistrarProveedor) {
            if (view.txt_IdentificacionProveedor.getText().equals("")
                    || view.txt_NombreProveedor.getText().equals("")
                    || view.txt_TelefonoProveedor.getText().equals("")
                    || view.txt_CorreoProveedor.getText().equals("")
                    || view.txt_DireccionProveedor.getText().equals("")
                    || view.txt_DescripcionProveedor.getText().equals("")) {

                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            } else {
                proveedor.setId(Integer.parseInt(view.txt_IdentificacionProveedor.getText().trim()));
                proveedor.setNombre(view.txt_NombreProveedor.getText().trim());
                proveedor.setTelefono(view.txt_TelefonoProveedor.getText().trim());
                proveedor.setCorreo(view.txt_CorreoProveedor.getText().trim());
                proveedor.setDireccion(view.txt_DireccionProveedor.getText().trim());
                proveedor.setProductos(view.txt_DescripcionProveedor.getText().trim());

                if (proveedoresDao.registrarProveedorQuery(proveedor)) {
                    limpiarTabla();
                    limpiarCampos();
                    listaProveedor();
                    JOptionPane.showMessageDialog(null, "Proveedor Registrado con exito");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al Registrar el Proveedor");
                }
            }
        } else if (e.getSource() == view.btn_ModificarProveedor) {
            if (view.txt_IdentificacionProveedor.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Selecciona una fila para continuar");
            } else {
                if (view.txt_IdentificacionProveedor.getText().equals("")
                        || view.txt_NombreProveedor.getText().equals("")
                        || view.txt_TelefonoProveedor.getText().equals("")
                        || view.txt_CorreoProveedor.getText().equals("")
                        || view.txt_DireccionProveedor.getText().equals("")
                        || view.txt_DescripcionProveedor.getText().equals("")) {

                    JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
                } else {
                    proveedor.setId(Integer.parseInt(view.txt_IdentificacionProveedor.getText().trim()));
                    proveedor.setNombre(view.txt_NombreProveedor.getText().trim());
                    proveedor.setTelefono(view.txt_TelefonoProveedor.getText().trim());
                    proveedor.setCorreo(view.txt_CorreoProveedor.getText().trim());
                    proveedor.setDireccion(view.txt_DireccionProveedor.getText().trim());
                    proveedor.setProductos(view.txt_DescripcionProveedor.getText().trim());

                    if (proveedoresDao.modificarProveedorQuery(proveedor)) {
                        limpiarTabla();
                        limpiarCampos();
                        listaProveedor();
                        view.btn_RegistrarProveedor.setEnabled(true);

                        JOptionPane.showMessageDialog(null, "Datos del Proveedor Modificado con Exito");
                    } else {
                        JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el Proveedor");
                    }
                }
            }
        } else if (e.getSource() == view.btn_EliminarProveedor) {
            int row = view.TablaProveedor.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(null, "Debes Seleccionar un Proveedor para eliminar");
            } else {
                int id = Integer.parseInt(view.TablaProveedor.getValueAt(row, 0).toString());
                int pregunta = JOptionPane.showConfirmDialog(null, "¿Deseas Eliminar a este Proveedor?");

                if (pregunta == 0 && proveedoresDao.eliminarProveedorQuery(id)) {
                    limpiarTabla();
                    limpiarCampos();
                    view.btn_RegistrarProveedor.setEnabled(true);
                    listaProveedor();
                    JOptionPane.showMessageDialog(null, "Proveedor Eliminado con Exito");
                }
            }
        } else if (e.getSource() == view.btn_CancelarProveedor) {
            view.btn_RegistrarProveedor.setEnabled(true);
            limpiarCampos();
        }

    }

//Listar Clientes
    public void listaProveedor() {
        List<Proveedor> lista = proveedoresDao.listaProveedorQuery(view.txt_BuscarProveedor.getText());
        modelo = (DefaultTableModel) view.TablaProveedor.getModel();

        Object[] row = new Object[6];
        for (int i = 0; i < lista.size(); i++) {
            row[0] = lista.get(i).getId();
            row[1] = lista.get(i).getNombre();
            row[2] = lista.get(i).getTelefono();
            row[3] = lista.get(i).getCorreo();
            row[4] = lista.get(i).getDireccion();
            row[5] = lista.get(i).getProductos();
            modelo.addRow(row);
        }

        view.TablaProveedor.setModel(modelo);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == view.TablaProveedor) {
            int row = view.TablaProveedor.rowAtPoint(e.getPoint());
            view.txt_IdentificacionProveedor.setText(view.TablaProveedor.getValueAt(row, 0).toString());
            view.txt_NombreProveedor.setText(view.TablaProveedor.getValueAt(row, 1).toString());
            view.txt_TelefonoProveedor.setText(view.TablaProveedor.getValueAt(row, 2).toString());
            view.txt_CorreoProveedor.setText(view.TablaProveedor.getValueAt(row, 3).toString());
            view.txt_DireccionProveedor.setText(view.TablaProveedor.getValueAt(row, 4).toString());
            view.txt_DescripcionProveedor.setText(view.TablaProveedor.getValueAt(row, 5).toString());

            view.btn_RegistrarProveedor.setEnabled(false);
            view.txt_IdentificacionCliente.setEditable(false);

        } else if (e.getSource() == view.jLabelProveedor) {
            String rol = rol_user;
            // Verificar si la condición de rol se evalúa correctamente
            if (rol != null && rol.trim().equals("Administrador")) {
                view.jTabbedPane1.setSelectedIndex(3);
                limpiarTabla();
                limpiarCampos();
                listaProveedor();
            } else {
                view.jTabbedPane1.setEnabledAt(3, false);
                view.jLabelCliente.setEnabled(false);
                JOptionPane.showMessageDialog(null, "No tienes Privilegios de Administrador para Acceder a esta vista");
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == view.txt_BuscarProveedor) {
            limpiarTabla();
            listaProveedor();
        }
    }

    public void limpiarCampos() {
        view.txt_IdentificacionProveedor.setText("");
        view.txt_IdentificacionProveedor.setEditable(true);
        view.txt_NombreProveedor.setText("");
        view.txt_TelefonoProveedor.setText("");
        view.txt_CorreoProveedor.setText("");
        view.txt_DireccionProveedor.setText("");
        view.txt_DescripcionProveedor.setText("");
    }

    public void limpiarTabla() {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }
    }

}
