
package main;

import view.InicioSesion;

public class main {
    public static void main(String[] args) {
        //Instanciar el login
        
        InicioSesion login = new InicioSesion();
        login.setVisible(true);
    }
}
