-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: heladeria_database
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administradora`
--

DROP TABLE IF EXISTS `administradora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administradora` (
  `id` int NOT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `usuario` varchar(60) DEFAULT NULL,
  `direccion` varchar(60) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  `rol` varchar(60) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradora`
--

LOCK TABLES `administradora` WRITE;
/*!40000 ALTER TABLE `administradora` DISABLE KEYS */;
INSERT INTO `administradora` VALUES (111,'Yefrey Sanchez Alba','ney','Villa del Rosarip','3128909897','ney@gmail.com','2468','Administrador','2024-04-14 17:06:48','2024-04-14 17:10:59'),(112,'Alejandro Villamizar','alejandro','Puerto Santander','3229876534','alejo@gmail.com','1369','Administrador','2024-04-14 17:07:38','2024-04-14 17:07:38'),(113,'Juliana','juliana','Lourdes','1423436734','juli@gmail.com','12345','Auxiliar','2024-04-15 10:12:24','2024-04-15 10:12:56'),(114,'Cristian Torres Carrero','cristian','Atalaya','3105818437','ctc@gmail.com','2006','Administrador',NULL,'2024-04-16 08:05:02');
/*!40000 ALTER TABLE `administradora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (7,'Bebidas Energizantes','2024-04-19 08:27:30','2024-04-19 08:27:30'),(8,'Bedidas Alcoholicas','2024-04-19 08:27:42','2024-04-19 08:27:42'),(9,'Bebidas Azucaradas','2024-04-19 08:27:51','2024-04-19 08:27:51'),(10,'Mecato','2024-04-19 08:52:32','2024-04-19 08:52:32'),(11,'Agua','2024-04-19 08:52:43','2024-04-19 08:52:43');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int NOT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `direccion` varchar(60) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Luz Mary Carrero','Atalaya','3202978716','luzcarrerro@gmail.com','2024-04-16 07:40:13','2024-04-16 07:40:13'),(3,'Elkin Torres Patiño','Motilones','12482892','elkin@gmail.com','2024-04-16 07:41:18','2024-04-16 07:42:44'),(123,'Andres','Kiosko','1938921','andres@gmail.com','2024-04-16 07:42:16','2024-04-16 07:42:58');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras`
--

DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras` (
  `id` int NOT NULL AUTO_INCREMENT,
  `total` double DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `producto_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compra_producto_idx` (`producto_id`),
  CONSTRAINT `compra_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
INSERT INTO `compras` VALUES (8,4000,'2024-04-20 14:24:39',NULL),(9,40000,'2024-04-20 14:49:55',NULL),(10,40000,'2024-04-20 14:57:51',NULL),(11,10000,'2024-04-20 15:00:46',NULL),(12,40000,'2024-04-20 15:06:36',NULL),(13,40000,'2024-04-20 15:07:12',NULL),(14,20000,'2024-04-20 15:15:28',NULL),(15,30000,'2024-04-20 15:16:19',NULL),(16,40000,'2024-04-20 15:23:14',NULL),(17,40000,'2024-04-20 15:26:56',NULL),(18,50000,'2024-04-20 15:27:40',NULL),(19,30000,'2024-04-20 15:28:37',NULL),(20,10000,'2024-04-20 15:34:03',NULL),(21,1000,'2024-04-20 15:35:01',NULL),(22,10000,'2024-04-20 15:40:38',NULL),(23,5000,'2024-04-20 15:41:12',NULL),(24,6000,'2024-04-20 15:41:37',NULL),(25,17500,'2024-04-20 16:29:35',NULL),(26,12000,'2024-04-20 16:37:48',NULL),(27,1000,'2024-04-20 16:40:35',NULL),(28,1000,'2024-04-20 16:41:43',NULL),(29,5500,'2024-04-20 16:55:07',NULL),(30,10000,'2024-04-20 16:58:53',NULL),(31,1800,'2024-04-20 17:02:33',NULL),(32,8750,'2024-04-20 17:04:50',NULL),(33,10000,'2024-04-20 17:08:29',NULL),(34,13000,'2024-04-20 17:21:01',NULL),(35,24000,'2024-04-20 17:26:55',NULL),(36,12400,'2024-04-20 17:33:57',NULL),(37,100,'2024-04-20 17:39:55',NULL),(38,10000,'2024-04-20 17:44:46',NULL),(39,3100,'2024-04-20 17:50:52',NULL),(40,6000,'2024-04-20 17:56:06',NULL),(41,21700,'2024-04-20 17:58:52',NULL);
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_compras`
--

DROP TABLE IF EXISTS `detalles_compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalles_compras` (
  `id` int NOT NULL AUTO_INCREMENT,
  `precio_compra` double DEFAULT NULL,
  `cantidad_compra` int DEFAULT NULL,
  `subtotal_compra` double DEFAULT NULL,
  `compra_id` int DEFAULT NULL,
  `producto_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compra_detalle_compra_idx` (`compra_id`),
  KEY `producto_detalle_compra_idx` (`producto_id`),
  CONSTRAINT `compra_detalle_compra` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`),
  CONSTRAINT `producto_detalle_compra` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_compras`
--

LOCK TABLES `detalles_compras` WRITE;
/*!40000 ALTER TABLE `detalles_compras` DISABLE KEYS */;
INSERT INTO `detalles_compras` VALUES (8,200,20,4000,8,5),(9,2000,20,40000,9,5),(10,2000,20,40000,10,5),(11,1000,10,10000,11,4),(12,2000,20,40000,12,5),(13,1000,30,30000,13,4),(14,1000,10,10000,13,5),(15,1000,20,20000,14,5),(16,1000,20,20000,15,4),(17,1000,10,10000,15,5),(18,2000,20,40000,16,6),(19,2000,20,40000,17,5),(20,1000,50,50000,18,1),(21,1000,30,30000,19,5),(22,2000,5,10000,20,5),(23,1000,1,1000,21,5),(24,2000,5,10000,22,4),(25,1000,5,5000,23,5),(26,2000,2,4000,25,4),(27,2500,3,7500,25,4),(28,1200,5,6000,25,6),(29,2000,5,10000,26,6),(30,1000,2,2000,26,5),(31,1000,1,1000,27,5),(32,1000,1,1000,28,5),(33,1500,1,1500,29,5),(34,1000,4,4000,29,4),(35,2000,5,10000,30,4),(36,1800,1,1800,31,4),(37,1750,5,8750,32,6),(38,2000,5,10000,33,4),(39,2600,5,13000,34,4),(40,2000,3,6000,35,5),(41,2300,2,4600,35,4),(42,1800,3,5400,35,6),(43,2000,4,8000,35,1),(44,1550,8,12400,36,4),(45,100,1,100,37,4),(46,2000,5,10000,38,6),(47,1550,2,3100,39,6),(48,1500,4,6000,40,4),(49,2000,1,2000,41,5),(50,2500,3,7500,41,4),(51,1300,2,2600,41,6),(52,3200,3,9600,41,1);
/*!40000 ALTER TABLE `detalles_compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` int DEFAULT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `precio_Unitario` double DEFAULT NULL,
  `cantidad_Producto` int DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `categoria_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_UNIQUE` (`codigo`),
  KEY `producto_categoria_idx` (`categoria_id`),
  CONSTRAINT `producto_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,129403,'Popetas','Sabor a Caramelo',1500,3,'2024-04-19 09:38:17','2024-04-19 10:45:21',10),(3,348734,'Paletas','Chocolate',2500,13,NULL,NULL,NULL),(4,12345,'Conos','Grande',5000,22,'2024-04-19 09:57:16','2024-04-19 17:22:32',7),(5,1234,'Cristal','Agua refrezcante 1000 ml',1500,1,'2024-04-19 16:54:51','2024-04-20 15:42:13',11),(6,98765,'Bonice','Sabor a Fresa Limon',1000,3,'2024-04-20 15:22:34','2024-04-20 15:22:34',7);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-22  8:19:09
